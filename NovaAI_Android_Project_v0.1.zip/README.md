# Nova AI — primera versión

Esta es la primera versión del proyecto Android.

Incluye:
- interfaz de chat
- historial local
- respuestas básicas
- estructura preparada para integrar un modelo de lenguaje local

IMPORTANTE:
Esta versión todavía NO contiene un modelo grande de IA. El siguiente paso es integrar un modelo local compatible con el teléfono.
